# 凡人打字机 (fr-cli)

基于智谱 AI (ZhipuAI/GLM) 的终极全能终端工具。

## ✨ 功能特性

- 🤖 **AI 对话**：基于 GLM-4 系列模型的智能对话
- 🧠 **MasterAgent 主控**：自我进化的 ReAct 主控 Agent，自动规划、调用工具、反思进化
- 🧩 **思维模式**：direct / CoT / ToT / ReAct 四种推理模式切换
- 📁 **文件沙盒**：安全的虚拟文件系统，支持读写/目录操作
- 🔍 **联网搜索**：内置 Web 搜索与网页内容提取（SSRF 防护）
- 🖼️ **视觉能力**：图片生成 (CogView) 与多模态识别 (GLM-4V)
- 📧 **邮件收发**：支持 IMAP/SMTP（防头注入）
- ⏰ **定时任务**：后台定时执行命令（shlex 安全解析）
- ☁️ **云盘集成**：百度/阿里/OneDrive 网盘
- 🔌 **插件系统**：AI 生成代码自动保存为插件（子进程隔离，无代码注入）
- 🧠 **会话记忆**：自动保留最近 5 轮对话摘要 + 按日期自动存档
- 🛡️ **安全确认**：四阶危险操作拦截 + 虚拟文件系统沙盒
- 👤 **Agent 分身系统**：AI 自动生成 Agent（人设/记忆/技能/代码），支持工作流编排
- 🌐 **Agent HTTP API**：将 Agent 发布为 REST API 供外部调用（默认 127.0.0.1 + Bearer Token）
- 🖥️ **本机应用启动**：一键调用浏览器、微信、Word、WPS 等本地程序
- 🧑‍💻 **内置 Agent**：`@local` `@remote` `@spider` `@db` `@RAG`
- 📊 **数据卷轴**：Excel / CSV 读取与智能分析
- 🗄️ **数据库助手**：MySQL / PostgreSQL / SQL Server / Oracle 智能 SQL 生成
- 📚 **本地 RAG**：ChromaDB 向量库 + 自动文件监控与向量化
- 🔗 **MCP 外部神通**：支持 Model Context Protocol，连接外部工具服务器（stdio/SSE）
- 🧠 **多源信息融合**：大模型初步回答 + 工具结果（搜索/RAG/MCP/Agent）统一汇总整理
- 🌍 **中英文切换**：完整国际化支持

## 🚀 快速安装

```bash
pip install fr-cli
fr-cli
```

首次运行会引导输入智谱 API Key。

## 📝 使用示例

### 终端命令

```bash
fr-cli

# 用户直接输入的命令
/ls                # 列出文件
/cat hello.md      # 查看文件
/cd /tmp           # 切换目录
/save mysession    # 保存会话
/export            # 导出为 Markdown
/agent_server start 8080   # 启动 Agent HTTP API
/agent_create coder "编写Python代码的助手"  # 自动生成Agent
/open /Users/me/doc.pdf    # 用默认应用打开文件
/launch chrome github.com  # 用 Chrome 打开网址
/launch 微信               # 启动微信
/apps                      # 列出可用应用
@local 查看当前目录最大的5个文件  # 本地系统操作Agent
@spider https://example.com 2  # 智能爬虫（深度2）
@db mydb 查询最近7天注册用户    # 数据库智能助手
@RAG 什么是向量数据库           # 本地知识库问答
/read_excel report.xlsx    # 读取 Excel
/read_csv data.csv         # 读取 CSV

# MasterAgent 自我进化主控
/master on                 # 启用主控Agent
/master off                # 关闭主控Agent
/master status             # 查看主控状态

# MCP 外部神通
/mcp_list                   # 列出已配置的 MCP 服务器及工具
/mcp_add fs npx -y @modelcontextprotocol/server-filesystem /tmp
/mcp_del fs                 # 删除 MCP 服务器
/mcp_enable fs              # 启用服务器
/mcp_disable fs             # 禁用服务器
/mcp_refresh                # 刷新工具列表

# 思维模式切换
/mode direct               # 直接回答（默认）
/mode cot                  # CoT 链式思考
/mode tot                  # ToT 树状搜索
/mode react                # ReAct 深度推理

# 自动会话存档
/session_list              # 列出按日期存档的会话
/session_load 0            # 加载第0个存档
/session_del 1             # 删除第1个存档

/help              # 查看帮助
/exit              # 退出
```

### AI 自动工具调用

向 AI 描述需求，它会自动调用内置工具：

```
>>> 搜索一下 Python 最新版本
🧙 仙人 [基于知识初步回答 + 调用 search_web 获取最新信息]
...
🤖 自动执行命令:
✅ 工具调用成功: search_web
...
🧙 仙人 [整理后的最终答案，融合自身知识与搜索结果]

>>> 把刚才的内容保存到文件
🧙 仙人 【调用：write_file({"path": "python_news.md", "content": "..."})】
✅ 卷轴已刻录
```

### Agent HTTP API 调用

启动服务后，外部系统可直接调用 Agent：

```bash
# 在 fr-cli 中启动服务
>>> /agent_server start 8080

# 外部系统调用（需携带 Bearer Token）
curl http://localhost:8080/agents \
  -H "Authorization: Bearer <token>"
curl -X POST http://localhost:8080/agents/my_agent/run \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"input": "请分析这个需求"}'
```

### 插件调用

自定义插件保持命令方式：

```
>>> 运行我的天气插件
🧙 仙人 【命令：/weather 北京】
```

## 📦 安装

```bash
# 一键安装（v2.1.0 起所有功能依赖默认包含）
pip install fr-cli
```

默认包含：智谱 AI SDK、HTTP 请求、Excel/CSV 处理、MySQL/PostgreSQL/SQL Server/Oracle 驱动、ChromaDB 向量库、sentence-transformers、SSH、Selenium、文件监控、云盘支持。

## 🔧 开发

```bash
git clone https://github.com/yourname/fr-cli.git
cd fr-cli
pip install -e .
python -m pytest tests/ -v
```

## 📄 License

MIT
